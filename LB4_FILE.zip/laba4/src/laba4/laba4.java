package laba4;

import java.util.Scanner;
public class laba4
{
	public static void main(String[] str) 
	{
		Scanner in=null;
		int v=10;
		while(v!=0) 
		{
			try
			{
				in=new Scanner(System.in);
				System.out.println("[1]Work with database");
				System.out.println("[2]Work with database(virtual)");
				System.out.println("[~]Exit");
				v=in.nextInt();
				switch(v)
				{
					case 1:one();break;
					case 2:two();break;
					case 3:break;
				}
			}
			catch(Exception ex) {System.out.print("Invalid data format!");};
		}
	}
	
	public static void one()
	{
		action.start();
		Scanner in=null;
		String v="";
		do
		{
			try
			{
				in=new Scanner(System.in);
				System.out.println("\n[1]Add\\Edit");
				System.out.println("[2]Print");
				System.out.println("[3]Delete");
				System.out.println("[4]Search");
				System.out.println("[5]Total amount of viewers");
				System.out.println("[6]Concert with max amount viewers");
				System.out.println("[7]The number of words in the genre name");
				System.out.println("[~]Exit");
				v=in.nextLine();
				switch(v)
				{
					case "1":action.add(); break;
					case "2":action.show(); break;
					case "3":action.delete(); break;
					case "4":action.search(); break;
					case "5": action.suma(); break;
					case "6": action.tooK();break;
					case "7":action.k_s(); break;
					default: System.out.print("Error value");
				}
			}
			catch(Exception ex) {System.out.print("Invalid data format!");};
		}
		while(v!="~");
	}
	
	public static void two()
	{
		action2.start();
		Scanner in=null;
		String v="";
		do 
		{
			try
			{
				in=new Scanner(System.in);
				System.out.println("\n[1]Add\\Edit");
				System.out.println("[2]Print");
				System.out.println("[3]Delete");
				System.out.println("[4]Search");
				System.out.println("[5]Total amount of viewers");
				System.out.println("[6]Concert with max amount viewers");
				System.out.println("[7]The number of words in the genre name");
				System.out.println("[~]Exit");
				v=in.nextLine();
				switch(v)
				{
				case "1":action2.add(); break;
				case "2":action2.show(); break;
				case "3":action2.delete(); break;
				case "4":action2.search(); break;
				case "5": action2.suma(); break;
				case "6": action2.tooK();break;
				case "7":action2.k_s(); break;
				default: System.out.print("Error value");
				}
			}
			catch(Exception ex) {System.out.print(ex.getMessage());};
		}
		while(v!="~");
	}
}
